"""
阿里云函数计算入口文件
======================

此文件适配阿里云函数计算FC环境，
将FastAPI应用转换为FC Handler格式。
"""

import os
import sys
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import json
import base64
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

# ============ FastAPI 应用初始化 ============
app = FastAPI(
    title="校园AI学习助手 API",
    description="提供AI资料整理和专注统计功能",
    version="1.0.0"
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 智谱AI配置
ZHIPU_API_KEY = os.environ.get("ZHIPU_API_KEY", "")
ZHIPU_API_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions"

# 专注记录存储（函数计算中使用）
focus_records = []


# ============ 数据模型 ============
class AnalyzeResponse(BaseModel):
    text: str
    keywords: List[str]
    summary: str
    outline: str
    mindmap: dict


# ============ API路由 ============
@app.get("/")
async def root():
    return {
        "name": "校园AI学习助手 API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/api/health")
async def health_check():
    return {
        "status": "ok",
        "api_provider": "zhipu",
        "api_configured": bool(ZHIPU_API_KEY)
    }


@app.post("/api/analyze")
async def analyze_content(file: UploadFile = File(None)):
    """AI内容分析接口"""
    content = await file.read() if file else b""
    
    # 调用AI分析
    result = await call_zhipu_ai(content.decode('utf-8', errors='ignore'))
    
    return result


@app.post("/api/focus/save")
async def save_focus_record(request: dict):
    """保存专注记录"""
    record = {
        "id": len(focus_records) + 1,
        "duration": request.get("duration", 0),
        "date": request.get("date", ""),
        "timestamp": request.get("timestamp", "")
    }
    focus_records.append(record)
    return {"success": True, "record": record}


@app.get("/api/focus/stats")
async def get_focus_stats():
    """获取专注统计"""
    today = focus_records[-1]["date"] if focus_records else ""
    return {
        "today": {"total": 0, "count": 0},
        "week": [],
        "total": {"total": sum(r["duration"] for r in focus_records), "count": len(focus_records)}
    }


async def call_zhipu_ai(content: str) -> dict:
    """调用智谱GLM-4 API"""
    if not ZHIPU_API_KEY:
        return get_mock_result(content)
    
    import requests
    
    prompt = f"""分析以下学习资料：
{content[:2000]}

返回JSON格式：
{{"text": "提取文本", "keywords": ["关键词"], "summary": "摘要", "outline": "# 提纲", "mindmap": {{"root": "主题", "branches": ["分支"]}}}}"""

    try:
        response = requests.post(
            ZHIPU_API_URL,
            headers={
                "Authorization": f"Bearer {ZHIPU_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": "glm-4-flash",
                "messages": [{"role": "user", "content": prompt}]
            },
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            content_text = result["choices"][0]["message"]["content"]
            try:
                return json.loads(content_text)
            except:
                return get_mock_result(content)
    except Exception as e:
        logger.error(f"API调用失败: {e}")
    
    return get_mock_result(content)


def get_mock_result(content: str) -> dict:
    """返回模拟结果"""
    return {
        "text": content[:1000] if content else "[请上传文件]",
        "keywords": ["人工智能", "机器学习", "数据分析", "深度学习", "神经网络"],
        "summary": "资料分析完成，详见下方内容。",
        "outline": "# 背诵提纲\n\n## 一、核心要点\n- 要点一\n- 要点二\n\n## 二、重点内容\n- 内容一\n- 内容二",
        "mindmap": {
            "root": "学习资料",
            "branches": ["核心概念", "重点分析", "实践应用", "总结"]
        }
    }


# ============ 阿里云函数计算入口 ============
def handler(environ, start_response):
    """
    阿里云FC入口函数
    ==================
    
    注意：阿里云函数计算需要使用WSGI接口，
    此处简化处理，实际部署请参考官方文档。
    """
    # 导入WSGI适配器
    from wsgiwapi import make_apps
    
    # 创建WSGI应用
    application = make_apps(app)
    
    # 调用WSGI处理
    return application(environ, start_response)


# 如果是本地测试，启用调试服务器
if __name__ == "__main__":
    import uvicorn
    print("🚀 启动本地服务: http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)
